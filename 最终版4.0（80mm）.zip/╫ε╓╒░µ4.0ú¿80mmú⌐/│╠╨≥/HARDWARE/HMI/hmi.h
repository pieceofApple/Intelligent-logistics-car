#ifndef __HMI_H
#define __HMI_H		
#include "sys.h"

void UART5_Process(void);

#endif
